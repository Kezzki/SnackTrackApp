import { useState, useEffect, useRef, useCallback } from "react";
import { X, Send, MessageCircle, Package, ChevronDown, Check, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useChat } from "@/contexts/ChatContext";
import { cn } from "@/lib/utils";

interface Message {
    id: string;
    sender_id: string;
    content: string;
    created_at: string;
    read_at: string | null;
    product_name?: string | null;
    product_image?: string | null;
}

interface PendingProduct {
    id?: string;
    name: string;
    image?: string;
}

// How long (ms) after the last keystroke before we broadcast "stopped typing"
const TYPING_STOP_DELAY = 2000;

function formatLastSeen(lastSeen: string | null): string {
    if (!lastSeen) return "Status tidak diketahui";
    const diffMs = Date.now() - new Date(lastSeen).getTime();
    const mins = Math.floor(diffMs / 60_000);
    if (mins < 5) return "Sedang online";
    if (mins < 60) return `Online ${mins} menit lalu`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `Online ${hours} jam lalu`;
    const days = Math.floor(hours / 24);
    if (days === 1) return "Online kemarin";
    return `Online ${days} hari lalu`;
}

function formatTime(ts: string): string {
    return new Date(ts).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

export function ChatOverlay() {
    const { activeChat, closeChat, defaultMinimized } = useChat();
    const { user } = useAuth();

    const [conversationId, setConversationId] = useState<string | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState("");
    const [sending, setSending] = useState(false);
    const [sellerLastSeen, setSellerLastSeen] = useState<string | null>(null);
    const [minimized, setMinimized] = useState(false);
    const [otherTyping, setOtherTyping] = useState(false);
    // True when a new message arrives while the overlay is minimised → triggers blink
    const [hasUnreadWhileMinimized, setHasUnreadWhileMinimized] = useState(false);
    // Product the buyer wants to inquire about — attached to the next sent message
    const [pendingProduct, setPendingProduct] = useState<PendingProduct | null>(null);

    const bottomRef = useRef<HTMLDivElement>(null);
    const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
    const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const isTypingRef = useRef(false);
    const minimizedRef = useRef(false); // stable ref for use inside Realtime callback

    // Keep own last_seen fresh while chat is open
    useEffect(() => {
        if (!user) return;
        const update = () =>
            supabase
                .from("profiles")
                .update({ last_seen: new Date().toISOString() })
                .eq("id", user.id)
                .then(() => {});
        update();
        const id = setInterval(update, 30_000);
        return () => clearInterval(id);
    }, [user]);

    // Pending product: only re-initialise when activeChat itself changes (not on user re-renders).
    // This prevents alt-tab / focus events that refresh the user reference from re-adding
    // a product the buyer already dismissed.
    useEffect(() => {
        if (!activeChat) {
            setPendingProduct(null);
            return;
        }
        if (activeChat.isProductInquiry && activeChat.productName) {
            setPendingProduct({
                id: activeChat.productId,
                name: activeChat.productName,
                image: activeChat.productImage,
            });
        } else {
            setPendingProduct(null);
        }
    }, [activeChat]); // intentionally excludes `user`

    // Open / reset when activeChat changes
    useEffect(() => {
        if (!activeChat || !user) {
            setConversationId(null);
            setMessages([]);
            return;
        }
        // Respect whether the caller wants it minimised (e.g. background notification)
        const startMinimized = defaultMinimized;
        setMinimized(startMinimized);
        minimizedRef.current = startMinimized;
        setHasUnreadWhileMinimized(false);

        (async () => {
            let convId = "";

            if (activeChat.conversationId) {
                // Conversation already known (e.g. opened from /pesan by either party)
                convId = activeChat.conversationId;
            } else {
                // Buyer initiating from a product page: find or create
                const { data: existing } = await supabase
                    .from("conversations")
                    .select("id")
                    .eq("buyer_id", user.id)
                    .eq("seller_id", activeChat.sellerId)
                    .eq("store_id", activeChat.storeId)
                    .maybeSingle();

                if (existing) {
                    convId = existing.id;
                } else {
                    const { data: created, error } = await supabase
                        .from("conversations")
                        .insert({
                            buyer_id: user.id,
                            seller_id: activeChat.sellerId,
                            store_id: activeChat.storeId,
                            product_id: activeChat.productId ?? null,
                            product_name: activeChat.productName ?? null,
                            product_image: activeChat.productImage ?? null,
                            last_message: "",
                            last_message_at: new Date().toISOString(),
                        })
                        .select("id")
                        .single();

                    if (error || !created) {
                        console.error("[ChatOverlay] Failed to create conversation:", error);
                        return;
                    }
                    convId = created.id;
                }
            }

            setConversationId(convId);

            // Load message history (include read_at for receipt ticks + product context)
            const { data: msgs } = await supabase
                .from("messages")
                .select("id, sender_id, content, created_at, read_at, product_name, product_image")
                .eq("conversation_id", convId)
                .order("created_at", { ascending: true });
            setMessages(msgs ?? []);

            // Fetch the OTHER party's last_seen for the status line.
            // sellerId is the store owner; if the current user IS the seller,
            // we instead want the buyer's last_seen. We resolve this by
            // fetching the conversation row to get the buyer_id when needed.
            const otherPartyId =
                user.id === activeChat.sellerId
                    ? null  // resolve below
                    : activeChat.sellerId;

            let resolvedOtherId = otherPartyId;
            if (!resolvedOtherId) {
                const { data: conv } = await supabase
                    .from("conversations")
                    .select("buyer_id")
                    .eq("id", convId)
                    .single();
                resolvedOtherId = (conv as any)?.buyer_id ?? null;
            }

            if (resolvedOtherId) {
                const { data: profile } = await supabase
                    .from("profiles")
                    .select("last_seen")
                    .eq("id", resolvedOtherId)
                    .single();
                setSellerLastSeen((profile as any)?.last_seen ?? null);
            }
        })();
    }, [activeChat, user, defaultMinimized]);

    // Real-time: new messages + read_at updates + typing broadcast
    useEffect(() => {
        if (!conversationId || !user) return;

        if (channelRef.current) supabase.removeChannel(channelRef.current);

        const channel = supabase
            .channel(`chat:${conversationId}`, { config: { broadcast: { self: false } } })
            // New messages
            .on(
                "postgres_changes",
                {
                    event: "INSERT",
                    schema: "public",
                    table: "messages",
                    filter: `conversation_id=eq.${conversationId}`,
                },
                (payload) => {
                    const newMsg = payload.new as Message;
                    setMessages((prev) =>
                        prev.some((m) => m.id === newMsg.id) ? prev : [...prev, newMsg]
                    );
                    // If overlay is minimised and the message is from someone else, trigger blink
                    if (minimizedRef.current && newMsg.sender_id !== user?.id) {
                        setHasUnreadWhileMinimized(true);
                    }
                }
            )
            // Read receipt: other party updated read_at on our sent messages
            .on(
                "postgres_changes",
                {
                    event: "UPDATE",
                    schema: "public",
                    table: "messages",
                    filter: `conversation_id=eq.${conversationId}`,
                },
                (payload) => {
                    const updated = payload.new as Message;
                    setMessages((prev) =>
                        prev.map((m) => (m.id === updated.id ? { ...m, read_at: updated.read_at } : m))
                    );
                }
            )
            // Typing indicator via Broadcast (ephemeral, no DB write)
            .on("broadcast", { event: "typing" }, (payload) => {
                if (payload.payload?.user_id === user.id) return; // ignore own events
                if (payload.payload?.typing) {
                    setOtherTyping(true);
                } else {
                    setOtherTyping(false);
                }
            })
            .subscribe();

        channelRef.current = channel;
        return () => {
            supabase.removeChannel(channel);
            if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
        };
    }, [conversationId, user]);

    // Mark incoming messages as read whenever the overlay is open and not minimised.
    // Also optimistically patches local state so the sender's receipt ticks update immediately.
    useEffect(() => {
        if (!conversationId || !user || minimized) return;
        const unread = messages.filter(
            (m) => m.sender_id !== user.id && !m.read_at
        );
        if (unread.length === 0) return;
        const ids = unread.map((m) => m.id);
        const now = new Date().toISOString();
        // Optimistic local update (so receipt ticks show without waiting for Realtime)
        setMessages((prev) =>
            prev.map((m) => (ids.includes(m.id) ? { ...m, read_at: now } : m))
        );
        supabase
            .from("messages")
            .update({ read_at: now })
            .in("id", ids)
            .then(() => {});
    }, [messages, conversationId, user, minimized]);

    // Keep minimizedRef in sync so Realtime callbacks can read it without stale closure
    useEffect(() => {
        minimizedRef.current = minimized;
    }, [minimized]);

    // Auto-scroll on new messages or when typing bubble appears
    useEffect(() => {
        if (!minimized) bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, minimized, otherTyping]);

    const broadcastTyping = useCallback((typing: boolean) => {
        if (!channelRef.current) return;
        channelRef.current.send({
            type: "broadcast",
            event: "typing",
            payload: { user_id: user?.id, typing },
        });
    }, [user]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setInput(e.target.value);
        if (!isTypingRef.current) {
            isTypingRef.current = true;
            broadcastTyping(true);
        }
        if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
        typingTimerRef.current = setTimeout(() => {
            isTypingRef.current = false;
            broadcastTyping(false);
        }, TYPING_STOP_DELAY);
    };

    const sendMessage = async () => {
        if (!input.trim() || !conversationId || !user || sending) return;
        const content = input.trim();
        const attachedProduct = pendingProduct;
        setInput("");
        setPendingProduct(null);
        setSending(true);

        // Stop typing indicator immediately on send
        if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
        isTypingRef.current = false;
        broadcastTyping(false);

        const { error } = await supabase.from("messages").insert({
            conversation_id: conversationId,
            sender_id: user.id,
            content,
            product_id: attachedProduct?.id ?? null,
            product_name: attachedProduct?.name ?? null,
            product_image: attachedProduct?.image ?? null,
        });

        if (!error) {
            await supabase
                .from("conversations")
                .update({ last_message: content, last_message_at: new Date().toISOString() })
                .eq("id", conversationId);
        }

        setSending(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    };

    if (!activeChat) return null;

    const storeInitials = activeChat.storeName
        .split(" ")
        .slice(0, 2)
        .map((w) => w[0])
        .join("")
        .toUpperCase();

    return (
        <div
            className={cn(
                "fixed bottom-0 right-0 z-[100] flex flex-col shadow-2xl overflow-hidden border bg-background",
                "w-full sm:w-[350px] md:w-[400px] sm:bottom-4 sm:right-4 sm:rounded-2xl rounded-t-2xl",
                "animate-fade-in transition-all duration-200",
                hasUnreadWhileMinimized && minimized
                    ? "border-primary/70 ring-2 ring-primary/40 animate-pulse"
                    : "border-border"
            )}
        >
            {/* Header */}
            <div className="flex items-center gap-3 px-4 py-3 gradient-primary text-white flex-shrink-0">
                {activeChat.storeAvatar ? (
                    <img
                        src={activeChat.storeAvatar}
                        alt={activeChat.storeName}
                        className="w-9 h-9 rounded-full object-cover border-2 border-white/30 flex-shrink-0"
                    />
                ) : (
                    <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 text-xs font-bold border-2 border-white/30">
                        {storeInitials}
                    </div>
                )}
                <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate leading-tight">{activeChat.storeName}</p>
                    <p className="text-[11px] text-white/70 truncate">
                        {otherTyping ? (
                            <span className="italic">sedang mengetik…</span>
                        ) : (
                            formatLastSeen(sellerLastSeen)
                        )}
                    </p>
                </div>
                {/* Unread dot — shown when minimised and there are new messages */}
                {hasUnreadWhileMinimized && minimized && (
                    <span className="w-2.5 h-2.5 rounded-full bg-warning flex-shrink-0 animate-pulse" />
                )}
                <div className="flex items-center gap-0.5">
                    <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-white hover:bg-white/15 rounded-full"
                        onClick={() => {
                            const next = !minimized;
                            setMinimized(next);
                            minimizedRef.current = next;
                            if (!next) setHasUnreadWhileMinimized(false); // clear blink when expanding
                        }}
                        title={minimized ? "Buka" : "Kecilkan"}
                    >
                        <ChevronDown
                            className={cn("h-4 w-4 transition-transform duration-200", minimized && "rotate-180")}
                        />
                    </Button>
                    <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-white hover:bg-white/15 rounded-full"
                        onClick={closeChat}
                        title="Tutup"
                    >
                        <X className="h-4 w-4" />
                    </Button>
                </div>
            </div>

            {!minimized && (
                <>
                    {/* Pending product inquiry — shown above the input (WhatsApp-style) */}

                    {/* Messages list */}
                    <div className="flex flex-col gap-2 p-4 overflow-y-auto h-[200px] sm:h-[320px] bg-background/95">
                        {messages.length === 0 ? (
                            <div className="flex flex-col items-center justify-center h-full gap-2 text-muted-foreground select-none">
                                <MessageCircle className="h-8 w-8 opacity-25" />
                                <p className="text-sm text-center">
                                    Mulai percakapan dengan
                                    <br />
                                    <span className="font-medium text-foreground">{activeChat.storeName}</span>
                                </p>
                            </div>
                        ) : (
                            messages.map((msg) => {
                                const isMine = msg.sender_id === user?.id;
                                const isRead = !!msg.read_at;
                                return (
                                    <div
                                        key={msg.id}
                                        className={cn("flex", isMine ? "justify-end" : "justify-start")}
                                    >
                                        <div
                                            className={cn(
                                                "max-w-[80%] px-3 py-2 rounded-2xl text-sm leading-snug break-words",
                                                isMine
                                                    ? "bg-primary text-primary-foreground rounded-br-sm"
                                                    : "bg-muted text-foreground rounded-bl-sm"
                                            )}
                                        >
                                            {/* Product inquiry card — attached to this specific message */}
                                            {msg.product_name && (
                                                <div className={cn(
                                                    "flex items-center gap-2 mb-1.5 p-1.5 rounded-lg border",
                                                    isMine
                                                        ? "bg-white/10 border-white/20"
                                                        : "bg-background/60 border-border"
                                                )}>
                                                    {msg.product_image ? (
                                                        <img
                                                            src={msg.product_image}
                                                            alt={msg.product_name}
                                                            className="w-8 h-8 rounded object-cover flex-shrink-0"
                                                        />
                                                    ) : (
                                                        <div className="w-8 h-8 rounded bg-muted flex items-center justify-center flex-shrink-0">
                                                            <Package className="h-3.5 w-3.5 text-muted-foreground" />
                                                        </div>
                                                    )}
                                                    <div className="min-w-0">
                                                        <p className={cn(
                                                            "text-[10px] leading-none mb-0.5",
                                                            isMine ? "text-primary-foreground/60" : "text-muted-foreground"
                                                        )}>Tanya tentang produk</p>
                                                        <p className="text-xs font-medium truncate">{msg.product_name}</p>
                                                    </div>
                                                </div>
                                            )}
                                            <p className="whitespace-pre-wrap">{msg.content}</p>
                                            <div
                                                className={cn(
                                                    "flex items-center gap-1 mt-0.5",
                                                    isMine ? "justify-end" : "justify-start"
                                                )}
                                            >
                                                <span
                                                    className={cn(
                                                        "text-[10px]",
                                                        isMine ? "text-primary-foreground/60" : "text-muted-foreground"
                                                    )}
                                                >
                                                    {formatTime(msg.created_at)}
                                                </span>
                                                {isMine && (
                                                    isRead ? (
                                                        <CheckCheck className="h-3 w-3 text-primary-foreground/80 flex-shrink-0" />
                                                    ) : (
                                                        <Check className="h-3 w-3 text-primary-foreground/40 flex-shrink-0" />
                                                    )
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })
                        )}

                        {/* Typing indicator bubble */}
                        {otherTyping && (
                            <div className="flex justify-start">
                                <div className="bg-muted rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:0ms]" />
                                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:150ms]" />
                                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:300ms]" />
                                </div>
                            </div>
                        )}

                        <div ref={bottomRef} />
                    </div>

                    {/* Pending product inquiry strip (WhatsApp-style) */}
                    {pendingProduct && (
                        <div className="flex items-center gap-2 mx-3 mb-1 px-2 py-1.5 rounded-lg bg-primary/10 border-l-2 border-primary">
                            {pendingProduct.image ? (
                                <img
                                    src={pendingProduct.image}
                                    alt={pendingProduct.name}
                                    className="w-8 h-8 rounded object-cover flex-shrink-0"
                                />
                            ) : (
                                <Package className="h-4 w-4 text-primary flex-shrink-0" />
                            )}
                            <div className="flex-1 min-w-0">
                                <p className="text-[10px] text-primary font-medium leading-none mb-0.5">Tanya tentang produk</p>
                                <p className="text-xs truncate text-foreground">{pendingProduct.name}</p>
                            </div>
                            <Button
                                size="icon"
                                variant="ghost"
                                className="h-5 w-5 text-muted-foreground hover:text-foreground flex-shrink-0"
                                onClick={() => setPendingProduct(null)}
                                title="Hapus lampiran"
                            >
                                <X className="h-3 w-3" />
                            </Button>
                        </div>
                    )}

                    {/* Input bar */}
                    <div className="flex items-center gap-2 px-3 py-2.5 border-t border-border bg-background flex-shrink-0">
                        <Input
                            placeholder="Ketik pesan..."
                            value={input}
                            onChange={handleInputChange}
                            onKeyDown={handleKeyDown}
                            className="flex-1 h-9 text-sm"
                            maxLength={500}
                            autoComplete="off"
                        />
                        <Button
                            size="icon"
                            className="h-9 w-9 flex-shrink-0"
                            onClick={sendMessage}
                            disabled={!input.trim() || sending}
                            title="Kirim"
                        >
                            <Send className="h-4 w-4" />
                        </Button>
                    </div>
                </>
            )}
        </div>
    );
}
