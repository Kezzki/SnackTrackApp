import { Store, MapPin, FileText, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useSellerStore } from "@/hooks/useSellerStore";
import { useOnboarding } from "@/contexts/OnboardingContext";

export function ShopProfileCard({ onUpdate }: { onUpdate: () => void }) {
  const { data: store, isLoading } = useSellerStore();
  const { isSellerOnboardingComplete } = useOnboarding();

  if (isLoading) return <div className="animate-pulse bg-muted rounded-xl h-48 w-full border border-border mb-8" />;

  if (!store && !isLoading) {
    return (
      <div className="bg-card rounded-xl border border-border p-6 shadow-sm mb-8 flex flex-col items-center justify-center gap-4 text-center">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
          <Store className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground text-lg mb-1">Profil Toko Belum Dibuat</h3>
          <p className="text-sm text-muted-foreground mb-4">Silahkan lengkapi profil toko Anda agar terlihat oleh pembeli.</p>
          <Button asChild>
            <Link to="/onboarding/penjual">Lengkapi Profil Sekarang</Link>
          </Button>
        </div>
      </div>
    );
  }

  if (!store) return null;

  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-sm mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Store className="w-6 h-6 text-primary" />
          Profil Toko
        </h2>
        {isSellerOnboardingComplete ? (
          <Button asChild variant="outline" size="sm">
            <Link to="/settings">Pengaturan Toko</Link>
          </Button>
        ) : (
          <Button asChild variant="outline" size="sm">
            <Link to="/onboarding/penjual">Lanjutkan Onboarding</Link>
          </Button>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Profile Image Section */}
        <div className="flex flex-col items-center gap-4 w-full md:w-auto">
          {store.image_url ? (
            <img 
              src={store.image_url} 
              alt={store.name} 
              className="w-32 h-32 rounded-2xl object-cover border-2 border-border shadow-sm"
            />
          ) : (
            <div className="w-32 h-32 rounded-2xl bg-primary/5 flex items-center justify-center border-2 border-dashed border-primary/20">
              <Store className="w-12 h-12 text-primary/40" />
            </div>
          )}
        </div>

        {/* Store Details Section */}
        <div className="flex-1 space-y-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              {store.name}
              <CheckCircle2 className="w-5 h-5 text-primary" />
            </h3>
          </div>
          
          <div className="flex items-start gap-3 text-sm text-muted-foreground">
            <FileText className="w-4 h-4 mt-0.5 shrink-0" />
            <p>{store.description || <span className="italic opacity-60">Belum ada deskripsi</span>}</p>
          </div>

          <div className="flex items-start gap-3 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
            <p>{store.address || <span className="italic opacity-60">Alamat belum diatur</span>}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
