import { createContext, useContext, useState, useEffect, useRef, ReactNode } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";

export interface ChatTarget {
    /** Pre-existing conversation id (when opening from /pesan) */
    conversationId?: string;
    storeId: string;
    storeName: string;
    storeAvatar?: string;
    /** auth.users id of the seller (store owner) */
    sellerId: string;
    productId?: string;
    productName?: string;
    productImage?: string;
    /** True when opened from a product page — product becomes a pending "inquiry" attached to the next sent message */
    isProductInquiry?: boolean;
}

interface ChatContextType {
    activeChat: ChatTarget | null;
    /** Whether the overlay should open in minimised state */
    defaultMinimized: boolean;
    openChat: (target: ChatTarget, minimized?: boolean) => void;
    closeChat: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: ReactNode }) {
    const { user } = useAuth();
    const [activeChat, setActiveChat] = useState<ChatTarget | null>(null);
    const [defaultMinimized, setDefaultMinimized] = useState(false);

    // Ref so the background listener can read the current chat without re-subscribing
    const activeChatRef = useRef<ChatTarget | null>(null);

    const openChat = (target: ChatTarget, minimized = false) => {
        setActiveChat(target);
        setDefaultMinimized(minimized);
        activeChatRef.current = target;
    };

    const closeChat = () => {
        setActiveChat(null);
        activeChatRef.current = null;
    };

    // ---------------------------------------------------------------
    // Background inbox listener
    // Pops up the overlay (minimised + blinking) when a new message
    // arrives in any conversation the user is part of, as long as they
    // are NOT already viewing that conversation.
    // ---------------------------------------------------------------
    useEffect(() => {
        if (!user) return;

        const channel = supabase
            .channel(`inbox:${user.id}`)
            .on(
                "postgres_changes",
                { event: "INSERT", schema: "public", table: "messages" },
                async (payload) => {
                    const msg = payload.new as {
                        id: string;
                        conversation_id: string;
                        sender_id: string;
                    };

                    // Ignore my own outgoing messages
                    if (msg.sender_id === user.id) return;
                    // Already viewing this conversation — overlay handles it inline
                    if (activeChatRef.current?.conversationId === msg.conversation_id) return;

                    // Fetch conversation details to populate the overlay header
                    const { data: conv } = await supabase
                        .from("conversations")
                        .select(
                            "id, store_id, seller_id, buyer_id, product_id, product_name, product_image, store:stores(name, image_url)"
                        )
                        .eq("id", msg.conversation_id)
                        .maybeSingle();

                    if (!conv) return;

                    let storeName: string = (conv as any).store?.name ?? "Pesan Baru";
                    let storeAvatar: string | undefined = (conv as any).store?.image_url ?? undefined;

                    // If the current user is the seller, show the buyer's name/avatar
                    if (user.id === (conv as any).seller_id) {
                        const { data: buyerProfile } = await supabase
                            .from("profiles")
                            .select("name, avatar_url")
                            .eq("id", (conv as any).buyer_id)
                            .single();
                        storeName = (buyerProfile as any)?.name ?? "Pembeli";
                        storeAvatar = (buyerProfile as any)?.avatar_url ?? undefined;
                    }

                    openChat(
                        {
                            conversationId: (conv as any).id,
                            storeId: (conv as any).store_id,
                            storeName,
                            storeAvatar,
                            sellerId: (conv as any).seller_id,
                            productId: (conv as any).product_id ?? undefined,
                            productName: (conv as any).product_name ?? undefined,
                            productImage: (conv as any).product_image ?? undefined,
                        },
                        true // open minimised so it doesn't disrupt the user's current action
                    );
                }
            )
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [user]);

    return (
        <ChatContext.Provider value={{ activeChat, defaultMinimized, openChat, closeChat }}>
            {children}
        </ChatContext.Provider>
    );
}

export function useChat() {
    const ctx = useContext(ChatContext);
    if (!ctx) throw new Error("useChat must be used within ChatProvider");
    return ctx;
}
