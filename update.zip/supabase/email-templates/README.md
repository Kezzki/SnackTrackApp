# Supabase Email Templates — Setup Guide

## Templates Included

| Template | File | Supabase Setting |
|----------|------|------------------|
| Registration Confirmation | `confirm-signup.html` | Auth → Email Templates → **Confirm signup** |
| Password Reset | `reset-password.html` | Auth → Email Templates → **Reset password** |
| Magic Link | `magic-link.html` | Auth → Email Templates → **Magic Link** |
| User Invitation | `invite-user.html` | Auth → Email Templates → **Invite user** |

## How to Set Up

1. Go to your **Supabase Dashboard** → **Authentication** → **Email Templates**
2. For each template type:
   - Open the corresponding `.html` file from `supabase/email-templates/`
   - Copy the **entire HTML content**
   - Paste it into the **Body** field in Supabase (switch to HTML/Source mode)
   - Set the **Subject** as follows:

| Template | Subject Line |
|----------|-------------|
| Confirm signup | `Konfirmasi Email Anda — SnackTrack` |
| Reset password | `Reset Password — SnackTrack` |
| Magic Link | `Login ke SnackTrack` |
| Invite user | `Anda Diundang ke SnackTrack! 🎊` |

3. Click **Save** for each template

## Template Variables

All templates use Supabase's built-in `{{ .ConfirmationURL }}` variable, which automatically gets replaced with the correct action URL. No additional configuration is needed.

## Customization

- **Colors**: The gradient uses `#374151 → #5B21B6 → #DB2777 → #D4A574` matching the app sidebar
- **Logo**: Uses Lucide cookie icon via Iconify CDN. Replace with your own logo URL if you have one
- **Copy**: All text is in Indonesian (Bahasa Indonesia) to match the app
